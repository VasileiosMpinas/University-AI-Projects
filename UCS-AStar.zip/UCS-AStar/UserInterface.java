/*
Christos Pergaminelis  4474
Vasileios Binas 4434
Agamemnonas Kyriazis 4400
*/
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.lang.System;
import javax.swing.JFileChooser;

public class UserInterface {
	static Scanner scanner = new Scanner(System.in);
	static JFileChooser fc = new JFileChooser();
	
	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("Choose the search operation:\n"
				+ "1) Uniform Cost Search\n"
				+ "2) A-star\n"
				+ "3) Benchmark");
		int search_mode = Integer.valueOf(scanner.nextLine());
		if (search_mode == 3) {
			runBenchmark();
			scanner.close();
			return;
		}
			
		System.out.println("1)Run one array\n"
				+ "2)Run with an input file");
		int mode = Integer.valueOf(scanner.nextLine());
		switch (mode) {
		case 1:
			runOneArray(search_mode);
			break;
		case 2:
			runFile(search_mode);
			break;
		default:
			break;
		}
		scanner.close();
	}
	
	private static void runFile(int search_mode) { // Run one search algorithm using a file as input
		System.out.println("Select input file");
		File file_input = new File(selectFolderGUI()); // after this point the program runs on full auto mode
		try {
			Scanner file_reader = new Scanner(file_input);
			while (file_reader.hasNextLine()) {
				String[] array = file_reader.nextLine().split(",");
				ArrayList<Short> label = new ArrayList<Short>();
				for (int i = 0; i < array.length; i++) {
					label.add(Short.valueOf(array[i]));
				}
				Node res = null;
				switch (search_mode) {
				case 1:
					UCS ucs = new UCS();
					res = ucs.UniformCostSearch(label);
					System.out.println(label);
					System.out.println(String.format("Path: %s\n", res.path)
							+ String.format("Path Cost: %d\n", res.cost)
							+ String.format("Total number of expansions: %d", ucs.getTotalNodes()));
					break;
				case 2:
					ASTAR astar = new ASTAR();
					res = astar.AStar(label);
					System.out.println(label);
					System.out.println(String.format("Path: %s\n", res.path)
							+ String.format("Path Cost: %d\n", res.cost)
							+ String.format("Total number of expansions: %d", astar.getTotalNodes()));
					break;
				default:
					break;
				}
			}
			file_reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	private static String selectFolderGUI() { // utility gui
		String file = null;
		int r;
		try {
			fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
			do {
				r = fc.showOpenDialog(null);
			} while (r == JFileChooser.ERROR_OPTION);
			try {
				file = fc.getSelectedFile().getCanonicalPath().toString();
				System.out.println(file);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			System.out.println("You need GUI support to run this application\n"
					+ "Please try one array mode if GUI is not available\n"
					+ "Terminating application, run the application again and select one array mode");
					System.exit(1);
		}
		return file;
	}
	
	private static void runOneArray(int search_mode) { // Run a search algorith with a single array as input
		ArrayList<Short> label = new ArrayList<Short>();
		System.out.println("Insert a number array:\n"
				+ "ex. 3,2,1,5,4");
		String[] array = scanner.nextLine().split(",");
		for (int i = 0; i < array.length; i++) {
			label.add(Short.valueOf(array[i]));
		} // after this point the program runs on full auto mode
		Node res = null;
		switch (search_mode) {
		case 1:
			UCS ucs = new UCS();
			res = ucs.UniformCostSearch(label);
			System.out.println(label);
			System.out.println(String.format("Path: %s\n", res.path)
					+ String.format("Path Cost: %d\n", res.cost)
					+ String.format("Total number of expansions: %d", ucs.getTotalNodes()));
			break;
		case 2:
			ASTAR astar = new ASTAR();
			res = astar.AStar(label);
			System.out.println(label);
			System.out.println(String.format("Path: %s\n", res.path)
					+ String.format("Path Cost: %d\n", res.cost)
					+ String.format("Total number of expansions: %d", astar.getTotalNodes()));
			break;
		default:
			break;
		}
	}
	
	private static void runBenchmark() { // Test the full potential of the program and view advanced statistics
		System.out.println("Select input file");
		File file_input = new File(selectFolderGUI()); // after this point the program runs on full auto mode
		try {
			Scanner file_reader = new Scanner(file_input);
			while (file_reader.hasNextLine()) {
				String[] array = file_reader.nextLine().split(",");
				ArrayList<Short> label = new ArrayList<Short>();
				for (int i = 0; i < array.length; i++) {
					label.add(Short.valueOf(array[i]));
				}
				UCS ucs = new UCS();
				long time_ucs = System.nanoTime();
				ucs.UniformCostSearch(label);
				time_ucs = System.nanoTime()-time_ucs;

				ASTAR astar = new ASTAR();
				long time_astar = System.nanoTime();
				astar.AStar(label);
				time_astar = System.nanoTime()-time_astar;

				System.out.println(String.format("Array : %s\nUCS expansions: %d A-STAR expansions: %d\nUCS time: %dns A-STAR time: %dns", 
						label, ucs.getTotalNodes(), astar.getTotalNodes(), time_ucs, time_astar));
			}
				file_reader.close();
		} catch (FileNotFoundException e) {
				e.printStackTrace();
		}
	}
}