
import java.util.ArrayList;

public class UtilityFunctions {
	
	public ArrayList<Short> T(int n, ArrayList<Short> label) { // the T() function
		ArrayList<Short> ra = new ArrayList<Short>(label);
		int i = 0;
		int j = n-1;
		while (i < j) {
			Short temp = label.get(i);
			ra.set(i, ra.get(j));
			ra.set(j, temp);
			i++;
			j--;
		}
		return ra;
	}
	
	public boolean isSorted(ArrayList<Short> label) { // checks if a node has a sorted label
		for(int i = 0; i < label.size()-1; i++) {
			if(label.get(i) > label.get(i+1)) {
				return false;
			}
		}
		return true;
	}
	
	public int heuristic(ArrayList<Short> label) { // the heuristic function used in A-star
	        ArrayList<Short> ra = new ArrayList<Short>(label);  
	        int res = 0;       
	        for (int i = 0; i < label.size()-1; i++)
	        {
	            if (ra.get(i+1)-ra.get(i) > 1 || ra.get(i)-ra.get(i+1) > 1)
	                res++; 
	        }
	        return res;
	}   
}