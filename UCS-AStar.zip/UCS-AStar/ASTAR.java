
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.PriorityQueue;

public class ASTAR {
	
	private class NodeComparator implements Comparator<Node> { // priority queue comparator

		@Override
		public int compare(Node node1, Node node2) {
			return node1.cost-node2.cost;
		}
		
	}
	
	private PriorityQueue<Node> frontier = new PriorityQueue<Node>(new NodeComparator()); // priority queue
	private HashMap<Integer, Integer> adjacencySet = new HashMap<Integer, Integer>(); // visited set
	private UtilityFunctions functions = new UtilityFunctions(); // utils
	private Integer weight = 1; // standard weight value
	private Integer totalNodes = 0; // total nodes expanded
	
	public void produceChildren(Node parentNode) {
		totalNodes++; // increase the number of nodes expanded
		for (int i = 2; i <= parentNode.label.size(); i++) { // iterate through all T(n)
			ArrayList<Short> label = functions.T(i, parentNode.label); // calculate T(n) for parent label
			boolean terminal = functions.isSorted(label); // set terminal state
			Node child = new Node(label, parentNode.cost + weight + functions.heuristic(label), 
					terminal, new ArrayList<String>(parentNode.path)); // initialize the child node + heuristic value
			child.path.add("T["+i+"]"); // update child's path
			if (!adjacencySet.keySet().contains(child.label.hashCode())) { // if the node we calculated has not been calculated before
				frontier.add(child); // add it to the pq
				adjacencySet.put(child.label.hashCode(), child.cost); // add it to the adjacency set
			} else {
				if (adjacencySet.get(child.label.hashCode()) > child.cost) { // if the node we calculated has been calculated before but with higher cost
					frontier.remove(child); // replace it
					frontier.add(child); // -//-
					adjacencySet.put(child.label.hashCode(), child.cost); // update it in the adjacency set
				}
			}
		}
	}
	
	public Node AStar(ArrayList<Short> label) {
		boolean terminal = functions.isSorted(label); // check if the root is terminal
		Node node = new Node(label, functions.heuristic(label), terminal, new ArrayList<String>()); // initialize root
		frontier.add(node); // append root to the priority queue
		adjacencySet.put(node.label.hashCode(), functions.heuristic(label)); // hash root into the adjacency set
		while (!frontier.isEmpty()) { // while there remain unexplored nodes pop min cost node from pq
			node = frontier.poll(); // pop from pq
			if(node.terminal) { // if the node is terminal return it
				return node; //success
			}
			produceChildren(node); // else expand the min cost node
		}
		return null; //failure
	}
	
	public Integer getTotalNodes() { // total nodes that the algorithm expanded
		return totalNodes;
	}
}