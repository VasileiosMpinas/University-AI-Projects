
import java.util.ArrayList;

public class Node {
	
	public ArrayList<Short> label;
	public Integer cost;
	public boolean terminal;
	public ArrayList<String> path;
	
	public Node(ArrayList<Short> list, Integer cost, boolean terminal, ArrayList<String> path) {
		this.label = list;
		this.cost = cost;
		this.terminal = terminal;
		this.path = path;
	}
	
	@Override
	public boolean equals(Object o) {
		Node node = (Node)o;
		return node.label.equals(this.label);
	}
	
	public String toString() {
		return String.format("terminal: %s\ncost: %d\n%s\nExpansion Path: %s", terminal, cost, label, path);
	}
}
