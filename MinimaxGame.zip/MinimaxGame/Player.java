
public class Player {

	int row;
	int column;
	
	public Player(int row, int column) {
		this.row = row;
		this.column = column;
	}
}
