
public class Tile {
	
	boolean canBeSteppedOn;
	int row;
	int column;
	
	public Tile (int row, int column) {
		canBeSteppedOn = true;
		this.row = row;
		this.column = column;
	}
	
	public Tile (Tile tile) {
		this.canBeSteppedOn = tile.canBeSteppedOn;
		this.row = tile.row;
		this.column = tile.column;
	}
	
	@Override
	public boolean equals(Object o) {
		if (o == null) {
			return false;
		}
		Tile tile = (Tile)o;
		return this.canBeSteppedOn == tile.canBeSteppedOn && this.row == tile.row
				&& this.column == tile.column;
	}
	
	public String toString() {
		if (this.canBeSteppedOn) {
			return "|O|";
		} else {
			return "|X|";
		}
	}
}
