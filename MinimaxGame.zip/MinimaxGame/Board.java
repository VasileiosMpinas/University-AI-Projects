import java.util.ArrayList;

public class Board {

	Tile[][] tiles;
	int[] dimensions;
	Player p1;
	Player p2;
	Integer step;
	
	public Board(int m, int n) {
		dimensions = new int[2];
		dimensions[0] = m;
		dimensions[1] = n;
		
		tiles = new Tile[m][n];
		
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				this.tiles[i][j] = new Tile(i, j);
			}
		}
		
		p1 = null;
		p2 = null;
	}
	
	public Board(Board board) {
		this.dimensions = board.dimensions;
		this.step = board.step;
		tiles = new Tile[dimensions[0]][dimensions[1]];
		for (int i = 0; i < dimensions[0]; i++) {
			for (int j = 0; j < dimensions[1]; j++) {
				this.tiles[i][j] = new Tile(board.tiles[i][j]);
			}
		}
		addPlayer("P1", board.p1.row, board.p1.column);
		addPlayer("P2", board.p2.row, board.p2.column);
	}

	public Tile getTileAtPos(int row, int col) {
		if (row < 0 || col < 0 || row > dimensions[0]-1 || col > dimensions[1]-1) {
			return null;
		}
		return tiles[row][col];
	}
	
	public void makeMove(Player player, Move move) {
		for (Tile tile: move.tileSequence) {
			player.row = tile.row;
			player.column = tile.column;
			tiles[tile.row][tile.column].canBeSteppedOn = false;
		}
	}
	
	public void addPlayer(String PLAYER, Integer row, Integer column) {
		Move move = new Move();
		Tile tile = getTileAtPos(row, column);
		move.tileSequence.add(tile);
		if (PLAYER.equals("P1")) {
			this.p1 = new Player(row, column);
			makeMove(p1, move);
		} else {
			this.p2 = new Player(row, column);
			makeMove(p2, move);
		}
	}
	
	public String toString() {
		String res = "";
		for (int i = 0; i < dimensions[0]; i++) {
			res += String.format("|%d|", i);
		}
		res += "\n";
		for (int i = 0; i < tiles.length; i++) {
			for (int j = 0; j < tiles[i].length; j++) {
				if (p1 == null && p2 == null) {
					res += String.format("%s", tiles[i][j]);
				} else if (p1 == null && p2 != null) {
					if (p2.row == i && p2.column == j) {
						res += String.format("%s", "|P|");
					} else {
						res += String.format("%s", tiles[i][j]);
					}
				} else if (p1 != null && p2 == null) {
					if (p1.row == i && p1.column == j) {
						res += String.format("%s", "|A|");
					} else {
						res += String.format("%s", tiles[i][j]);
					}
				} else {
					if (p1.row == i && p1.column == j) {
						res += String.format("%s", "|A|");
					} else if (p2.row == i && p2.column == j) {
						res += String.format("%s", "|P|");
					} else {
						res += String.format("%s", tiles[i][j]);
					}
				}
			}
			res += String.format("|%d|\n", i);
		}
		return res;
	}
	
	public ArrayList<Move> getPlayerAvailableMoves(Player player) {
		ArrayList<Move> moves = new ArrayList<Move>();
		
		for (int i = 1; i <= step; i++) {
			Move move = new Move();
			Tile tile = null;
			for (int j = 1; j <= i; j++) {
				tile = getTileAtPos(player.row+j, player.column);
				if (tile == null || !tile.canBeSteppedOn) {
					tile = null;
					break;
				}
				move.tileSequence.add(tile);
			}
			if  (tile == null) {
				break;
			}
			moves.add(move);
		}
		for (int i = 1; i <= step; i++) {
			Move move = new Move();
			Tile tile = null;
			for (int j = 1; j <= i; j++) {
				tile = getTileAtPos(player.row-j, player.column);
				if (tile == null || !tile.canBeSteppedOn) {
					tile = null;
					break;
				}
				move.tileSequence.add(tile);
			}
			if  (tile == null) {
				break;
			}
			moves.add(move);
		}
		for (int i = 1; i <= step; i++) {
			Move move = new Move();
			Tile tile = null;
			for (int j = 1; j <= i; j++) {
				tile = getTileAtPos(player.row, player.column+j);
				if (tile == null || !tile.canBeSteppedOn) {
					tile = null;
					break;
				}
				move.tileSequence.add(tile);
			}
			if  (tile == null) {
				break;
			}
			moves.add(move);
		}
		for (int i = 1; i <= step; i++) {
			Move move = new Move();
			Tile tile = null;
			for (int j = 1; j <= i; j++) {
				tile = getTileAtPos(player.row, player.column-j);
				if (tile == null || !tile.canBeSteppedOn) {
					tile = null;
					break;
				}
				move.tileSequence.add(tile);
			}
			if  (tile == null) {
				break;
			}
			moves.add(move);
		}
		for (int i = 1; i <= step; i++) {
			Move move = new Move();
			Tile tile = null;
			for (int j = 1; j <= i; j++) {
				tile = getTileAtPos(player.row-j, player.column-j);
				if (tile == null || !tile.canBeSteppedOn) {
					tile = null;
					break;
				}
				move.tileSequence.add(tile);
			}
			if  (tile == null) {
				break;
			}
			moves.add(move);
		}
		for (int i = 1; i <= step; i++) {
			Move move = new Move();
			Tile tile = null;
			for (int j = 1; j <= i; j++) {
				tile = getTileAtPos(player.row+j, player.column-j);
				if (tile == null || !tile.canBeSteppedOn) {
					tile = null;
					break;
				}
				move.tileSequence.add(tile);
			}
			if  (tile == null) {
				break;
			}
			moves.add(move);
		}
		for (int i = 1; i <= step; i++) {
			Move move = new Move();
			Tile tile = null;
			for (int j = 1; j <= i; j++) {
				tile = getTileAtPos(player.row-j, player.column+j);
				if (tile == null || !tile.canBeSteppedOn) {
					tile = null;
					break;
				}
				move.tileSequence.add(tile);
			}
			if  (tile == null) {
				break;
			}
			moves.add(move);
		}
		for (int i = 1; i <= step; i++) {
			Move move = new Move();
			Tile tile = null;
			for (int j = 1; j <= i; j++) {
				tile = getTileAtPos(player.row+j, player.column+j);
				if (tile == null || !tile.canBeSteppedOn) {
					tile = null;
					break;
				}
				move.tileSequence.add(tile);
			}
			if  (tile == null) {
				break;
			}
			moves.add(move);
		}
		return moves;
	}
	
	public Boolean isTerminal() {
		return getPlayerAvailableMoves(p1).isEmpty() || getPlayerAvailableMoves(p2).isEmpty();
	}
	
	public Integer evaluateBoard(String MINIMAX) {
		int p1Moves = getPlayerAvailableMoves(p1).size();
		int p2Moves = getPlayerAvailableMoves(p2).size();
		if (p1Moves == 0 && p2Moves == 0) {
			if (MINIMAX.equals("MIN")) {
				return 0;
			} else {
				return -10;
			}
		} else if (p1Moves == 0 && p2Moves != 0) {
			return p2Moves*(-10);
		}
		else { // (p2Tiles == 0 && p1Tiles != 0) 
			return p1Moves*(10);
		}
	}
}
