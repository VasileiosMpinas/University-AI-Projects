import java.util.ArrayList;

public class Move {

	ArrayList<Tile> tileSequence;
	
	public Move() {
		tileSequence = new ArrayList<Tile>();
	}
	
	public String toString() {
		String res = "";
		for (Tile tile: tileSequence) {
			res += String.format("%s %s %s", tile.row, tile.column, tile);
		}
		return res;
	}
}
