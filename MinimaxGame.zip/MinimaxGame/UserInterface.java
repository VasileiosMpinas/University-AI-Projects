/*
Christos Pergaminelis  4474
Vasileios Binas 4434
Agamemnonas Kyriazis 4400
*/
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;


public class UserInterface {
	
	final static int INFINITY = (int) Math.pow(10, 5);
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		Board board = setupGame();
		int res = runGame(board);
		System.out.println(res);
	}

	public static Board setupGame() {
		
		System.out.println("Type board dimensions:\n"
				+ "ex. 3 3 (rows columns)");
		int rows = scanner.nextInt();
		int columns = scanner.nextInt();
		Board board = new Board(rows, columns);
		System.out.println(board);
		
		System.out.println("Type how many tiles you want to remove:");
		int i = scanner.nextInt();
		while (i > 0) {
			System.out.println("Blacken out any tiles you want\n"
					+ "ex. 0 3 (row column)");
			int row = scanner.nextInt();
			int column = scanner.nextInt();
			Tile tile = board.getTileAtPos(row, column);
			if (tile == null)
				continue;
			tile.canBeSteppedOn = false;
			i--;
			System.out.println(board);
		}
		
		System.out.println("Set p1/MAX position:\n"
				+ "ex. 0 3 (row column)");
		int row = scanner.nextInt();
		int column = scanner.nextInt();
		board.addPlayer("P1", row, column);
		System.out.println(board);
		
		System.out.println("Set p2/MIN position:\n"
				+ "ex. 0 3 (row column)");
		row = scanner.nextInt();
		column = scanner.nextInt();
		board.addPlayer("P2", row, column);
		System.out.println(board);
		
		System.out.println("Set maximum step size:");
		board.step = scanner.nextInt();
		
		return board;
	}
	
	public static int runGame(Board board) {
		while (true) {
			// MAX
			ArrayList<Move> p1Moves = board.getPlayerAvailableMoves(board.p1);
			if (p1Moves.isEmpty()) {
				System.out.println("HUMANITY WINS");
				System.out.println(board);
				return 1;
			}
			Move p1move = findP1BestMove(board, p1Moves);
			board.makeMove(board.p1, p1move);
			System.out.println(board);
			// MIN
			ArrayList<Move> p2Moves = board.getPlayerAvailableMoves(board.p2);
			if (p2Moves.isEmpty()) {
				System.out.println("AI WINS");
				System.out.println(board);
				return 0;
			}
			Move p2move = pickValidMove(p2Moves);
			board.makeMove(board.p2, p2move);
			System.out.println(board);
		}
	}
	
	public static Move pickValidMove(ArrayList<Move> p2Moves) {
		Move move = null;
		
		while (move == null) {
			System.out.println("Type your next move:");
			int row = scanner.nextInt();
			int column = scanner.nextInt();
			Tile tile = new Tile(row, column);
			for (Move p2Move: p2Moves) {
				if (tile.equals(p2Move.tileSequence.get(p2Move.tileSequence.size()-1))) {
					move = p2Move;
					break;
				}
			}
		}
		return move;
	}

	public static Move findP1BestMove(Board board, ArrayList<Move> p1Moves) {
		Move bestMove = null;
		int maxValue = -INFINITY;
		for (Move move: p1Moves) {
			Board child = new Board(board);
			child.makeMove(child.p1, move);
			int value = minimax("MIN", child);
			if (maxValue < value) {
				maxValue = value;
				bestMove = move;
			}
		}
		return bestMove;
	}

	public static int minimax(String MINIMAX, Board board) {
		if (board.isTerminal()) {
			int value = board.evaluateBoard(MINIMAX);
			return value;
		}
		if (MINIMAX.equals("MAX")) {
			int maxValue = -INFINITY;
			ArrayList<Move> p1Moves = board.getPlayerAvailableMoves(board.p1);
			for (Move move: p1Moves) { // For each move
				Board child = new Board(board);
				child.makeMove(child.p1, move);
				int value = minimax("MIN", child);
				if (value > maxValue) {
					maxValue = value;
				}
			}
			return maxValue;
		} else {
			int minValue = INFINITY;
			ArrayList<Move> p2Moves = board.getPlayerAvailableMoves(board.p2);
			for (Move move: p2Moves) { // For each move
				Board child = new Board(board);
				child.makeMove(child.p2, move);
				int value = minimax("MAX", child);
				if (value < minValue) {
					minValue = value;
				}
			}
			return minValue;
		}
	}
	
	public static Move chooseRandomMove(ArrayList<Move> availableMoves) {
		Random random = new Random();
		return availableMoves.get(random.nextInt(availableMoves.size()));
	}
}
